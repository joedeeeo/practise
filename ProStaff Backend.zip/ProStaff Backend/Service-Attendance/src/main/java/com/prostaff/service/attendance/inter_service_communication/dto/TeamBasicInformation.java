package com.prostaff.service.attendance.inter_service_communication.dto;

import lombok.Data;

@Data
public class TeamBasicInformation {

	 String name; 
	 String description;
	 Long employeeCount;
}
