package com.prostaff.service.designation.inter_service_communication.enums;

public enum Role {
	EMPLOYEE, ADMIN
}
