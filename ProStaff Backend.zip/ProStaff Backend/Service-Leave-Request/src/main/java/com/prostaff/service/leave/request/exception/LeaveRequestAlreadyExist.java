package com.prostaff.service.leave.request.exception;

public class LeaveRequestAlreadyExist extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
