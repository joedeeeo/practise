package com.prostaff.service.leave.request;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceLeaveRequestApplicationTests {

	@Test
	void contextLoads() {
	}

}
