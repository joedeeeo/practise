package com.prostaff.service.department.inter_service_communication.enums;

public enum Role {
	EMPLOYEE, ADMIN
}
