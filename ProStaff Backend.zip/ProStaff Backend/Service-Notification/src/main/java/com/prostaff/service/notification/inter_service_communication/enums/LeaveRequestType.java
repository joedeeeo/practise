package com.prostaff.service.notification.inter_service_communication.enums;

public enum LeaveRequestType {
	PAID, UNPAID, SICK
}
