package com.prostaff.service.notification;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceNotificationApplicationTests {

	@Test
	void contextLoads() {
	}

}
