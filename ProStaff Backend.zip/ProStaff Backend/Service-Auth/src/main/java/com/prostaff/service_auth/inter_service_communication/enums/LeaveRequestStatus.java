package com.prostaff.service_auth.inter_service_communication.enums;

public enum LeaveRequestStatus {
	ACCEPTED, REJECTED, PENDING
}
