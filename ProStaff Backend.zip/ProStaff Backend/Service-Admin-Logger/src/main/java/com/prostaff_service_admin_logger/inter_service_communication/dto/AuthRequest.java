package com.prostaff_service_admin_logger.inter_service_communication.dto;

public class AuthRequest {
	
	String jwtToken;
	String path; 
	
}
