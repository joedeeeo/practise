package com.prostaff_service_admin_logger.inter_service_communication.dto;

import org.springframework.core.io.Resource;

public class OrganizationData {
	
	String organizationName; 
    Resource image;
}
