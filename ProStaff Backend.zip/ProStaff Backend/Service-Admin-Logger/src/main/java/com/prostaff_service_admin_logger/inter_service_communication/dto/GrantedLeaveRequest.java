package com.prostaff_service_admin_logger.inter_service_communication.dto;

import java.sql.Date;

public class GrantedLeaveRequest {
	
	String employeeEmail; 
	String adminEmail; 
	Date date; 
	
}
