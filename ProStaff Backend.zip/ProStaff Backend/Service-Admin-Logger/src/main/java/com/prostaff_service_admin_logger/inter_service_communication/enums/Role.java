package com.prostaff_service_admin_logger.inter_service_communication.enums;

public enum Role {
	EMPLOYEE, ADMIN
}
